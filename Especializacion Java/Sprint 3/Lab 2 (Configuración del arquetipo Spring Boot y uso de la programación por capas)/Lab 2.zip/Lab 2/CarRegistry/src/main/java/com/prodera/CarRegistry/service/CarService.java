package com.prodera.CarRegistry.service;

public interface CarService {
    void logDefaultCarMake();
}
