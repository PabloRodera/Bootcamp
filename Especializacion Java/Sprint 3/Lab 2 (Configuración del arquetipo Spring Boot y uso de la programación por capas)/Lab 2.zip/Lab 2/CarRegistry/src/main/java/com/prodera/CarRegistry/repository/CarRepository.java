package com.prodera.CarRegistry.repository;

import com.prodera.CarRegistry.model.Car;

public interface CarRepository {
    Car getCar();
}
