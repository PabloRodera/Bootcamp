package com.prodera.CarRegistry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarRegistryApplicationTests {

	@Test
	void contextLoads() {
	}
}
